from flask import request
from faculty_app.services.faculty_service import FacultyService
from faculty_app.views.faculty_view import FacultyView

class FacultyController:
    @staticmethod       # Indicates that this method does not depend on instance-level data.
    def get_all_faculties():
        faculties = FacultyService.get_all_faculties()
        return FacultyView.render_faculties(faculties), 200

    @staticmethod
    def get_faculty(full_name):
        faculty = FacultyService.get_faculty_by_username(full_name)
        if not faculty:  # if faculty is None:
            return FacultyView.render_error('Faculty not found'), 404
        return FacultyView.render_faculty(faculty), 200

    @staticmethod
    def create_faculty():
        data = request.get_json()      # Extracts JSON payload from the HTTP request.
        full_name = data.get('full_name','')
        email = data.get('email')
        phone_number = data.get('phone_number')
        password_hash = data.get('password_hash')
        course_name = data.get('course_name')
        experience = data.get('experience')

        faculty = FacultyService.create_faculty(full_name, email, course_name, experience, password_hash, phone_number)
        return FacultyView.render_success('Faculty created successfully', faculty.faculty_id), 201

    @staticmethod
    def login_faculty():
        data = request.get_json()
        faculty_id = data.get('faculty_id')
        password = data.get('password')

        faculty = FacultyService.verify_faculty(faculty_id, password)
        if faculty:
            return FacultyView.render_success('Login successful', faculty.faculty_id), 200
        return FacultyView.render_error('Invalid id or password'), 401

