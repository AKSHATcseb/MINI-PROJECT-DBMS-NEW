from flask import Blueprint
# imports blueprint class
from faculty_app.controllers.faculty_controller import FacultyController

faculty_bp = Blueprint('faculty_bp', __name__)
# Creates a new Blueprint instance named faculty_bp. The first argument 'faculty_bp' is the name of the blueprint, and the second argument __name__ specifies the blueprint’s module or context.

@faculty_bp.route('/api/faculties', methods=['POST'])
def register_faculty():
    return FacultyController.register_faculty()

@faculty_bp.route('/api/faculties', methods=['GET'])
def get_all_faculties():
    return FacultyController.get_all_faculties()

@faculty_bp.route('/api/faculties/<full_name>', methods=['GET'])
def get_faculty(full_name):
    return FacultyController.get_faculty(full_name)

@faculty_bp.route('/api/faculties/login', methods=['POST'])
def login_faculty():
    return FacultyController.login_faculty()
