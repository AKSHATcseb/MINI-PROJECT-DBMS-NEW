from flask import Blueprint
# imports blueprint class
from course_app.controllers.course_controller import CourseController


course_bp = Blueprint('course_bp', __name__)
# Creates a new Blueprint instance named course_bp. The first argument 'course_bp' is the name of the blueprint, and the second argument __name__ specifies the blueprint’s module or context.


@course_bp.route('/api/courses', methods=['GET'])
def get_all_courses():
    return CourseController.get_all_courses()

@course_bp.route('/api/courses', methods=['POST'])
def introduce_course():
    return CourseController.introduce_course()

@course_bp.route('/api/courses/<course_name>', methods=['GET'])
def get_course(course_name):
    return CourseController.get_course(course_name)

@course_bp.route('/api/courses/<int:course_id>', methods=['DELETE'])
def delete_course(course_id):
    return CourseController.delete_course(course_id)
