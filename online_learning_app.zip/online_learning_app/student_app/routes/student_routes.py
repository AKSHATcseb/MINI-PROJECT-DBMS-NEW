from flask import Blueprint
from student_app.controllers.student_controller import StudentController


student_bp = Blueprint('student_bp', __name__)

@student_bp.route('/api/students', methods=['GET'])
def get_all_students():
    return StudentController.get_all_students()

@student_bp.route('/api/students/<int:std_class>', methods=['GET'])
def get_all_students_of_class(student_class):
    return StudentController.get_all_students(student_class)

@student_bp.route('/api/students/<int:student_admNo>', methods=['GET'])
def get_student(student_admNo):
    return StudentController.get_student(student_admNo)

@student_bp.route('/api/students', methods=['POST'])
def enroll_student():
    return StudentController.enroll_student()

# @student_bp.route('/api/students/<int:student_id>', methods=['PUT'])
# def update_student(student_id):
#     return StudentController.update_student(student_id)

# @student_bp.route('/api/students/<int:student_id>', methods=['DELETE'])
# def delete_student(student_id):
#     return StudentController.delete_student(student_id)
