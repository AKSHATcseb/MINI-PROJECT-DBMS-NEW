from flask import request
from course_app.services.course_service import CourseService
from course_app.views.course_view import CourseView

class CourseController:
    @staticmethod       # Indicates that this method does not depend on instance-level data.
    def get_all_courses():
        courses = CourseService.get_all_courses()
        return CourseView.render_courses(courses), 200

    @staticmethod
    def get_course(course_name):
        course = CourseService.get_course_by_name(course_name)
        if not course:  # if course is None:
            return CourseView.render_error('Course not found'), 404
        return CourseView.render_course(course), 200

    @staticmethod
    def introduce_course():
        data = request.get_json()  # Extracts JSON payload from the HTTP request.
        course_name = data.get('course_name')
        course_duration = data.get('course_duration')

        course = CourseService.introduce_course(course_name, course_duration)
        return CourseView.render_success('Course created successfully', course.course_id), 201

    @staticmethod
    def delete_course(course_id):
        student = CourseService.delete_course(course_id)
        if student:
            return CourseView.render_success('Course deleted successfully', course_id), 200
        return CourseView.render_error('Course not found'), 404
