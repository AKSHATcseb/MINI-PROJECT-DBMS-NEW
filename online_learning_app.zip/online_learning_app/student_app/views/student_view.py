class StudentView:

    @staticmethod
    def render_student(student):
        return {
            "student_admNo": student.student_admNo,
            "full_name":student.full_name,
            "course_name": student.course_name,
            "father_name": student.father_name,
            "mother_name": student.mother_name,
            "student_class": student.student_class,
            "phone_number": student.phone_number,
            "email": student.email,
        }


    @staticmethod
    def render_students(students):
        return [StudentView.render_student(student) for student in students]

    @staticmethod
    def render_error(message):
        return {"error": message}

    @staticmethod
    def render_success(message, student_admNo=None):
        response = {"message": message}
        if student_admNo:
            response["student_admNo"] = student_admNo
        return response

    