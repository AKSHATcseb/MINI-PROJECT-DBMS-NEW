import sys, os
# These modules are used for system-specific parameters and file path manipulations.

sys.path.append(os.getcwd())
# Appends the current working directory (os.getcwd()) to Python's search path (sys.path), ensuring modules in the current directory can be imported.

from flask import Flask
from faculty_app.routes.faculty_routes import faculty_bp
from shared.utils.db_utils import db
from shared.models import model

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:7070@localhost/social_media_app_learning'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = True

db.init_app(app)

app.register_blueprint(faculty_bp)

if __name__ == '__main__':
    app.run(debug=True, port=5006)
