from shared.models.model import Course
from shared.utils.db_utils import db
# Purpose: Imports the db object (likely an SQLAlchemy instance) for database operations (e.g., adding, querying, committing).
from werkzeug.security import generate_password_hash, check_password_hash
# Provides utility functions to hash passwords (generate_password_hash) and validate them (check_password_hash).

class CourseService:
    @staticmethod
    def introduce_course(course_name, course_duration):
        new_course = Course(course_name=course_name, course_duration = course_duration)
        db.session.add(new_course)
        db.session.commit()

        return new_course
    
    @staticmethod
    def get_course_by_name(course_name):
        return Course.query.filter_by(course_name=course_name).first()

    @staticmethod
    def get_all_courses():
        return Course.query.all()

    @staticmethod
    def delete_course(course_id):
        course = Course.query.filter_by(course_id=course_id).first()
        if course:
            db.session.delete(course)
            db.session.commit()
        return course
