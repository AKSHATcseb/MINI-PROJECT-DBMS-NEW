from flask import request
from student_app.services.student_service import StudentService
from student_app.views.student_view import StudentView

class StudentController:
    @staticmethod
    def get_all_students():
        students = StudentService.get_all_students()
        return StudentView.render_students(students), 200
    
    @staticmethod
    def get_all_students_of_class(student_class):
        students = StudentService.get_all_students_of_class(student_class)
        return StudentView.render_students(students), 200
    
    @staticmethod
    def get_student(student_id):
        student = StudentService.get_student_by_id(student_id)
        if not student:
            return StudentView.render_error('Student not found'), 404
        return StudentView.render_student(student), 200

    @staticmethod
    def enroll_student():
        data = request.get_json()      #  Extracts JSON payload from the HTTP request.
        full_name = data.get('full_name', '')
        email = data.get('email')
        phone_number = data.get('phone_number')
        student_class = data.get('student_class')
        father_name = data.get('father_name')
        mother_name = data.get('mother_name')
        password = data.get('password')
        address = data.get('address')
        course_id = data.get('course_id')


        student = StudentService.create_user(full_name, phone_number, student_class, father_name, mother_name,  email, password, address, course_id)
        return StudentView.render_success('Student enrolled successfully', student.student_admNo), 201

    # @staticmethod
    # def update_student(student_admNo):
    #     data = request.get_json()
    #     new_information = data.get('')

    #     student = StudentService.update_student(student_id, new_content)
    #     if student:
    #         return StudentView.render_success('Student updated successfully', student.student_id), 200
    #     return StudentView.render_error('Student not found'), 404

    # @staticmethod
    # def delete_student(student_admNo):
    #     student = StudentService.delete_student(student_admNo)
    #     if student:
    #         return StudentView.render_success('Student deleted successfully', student.student_admNo), 200
    #     return StudentView.render_error('Student not found'), 404
