from shared.models.model import Student
from shared.utils.db_utils import db
from shared.models.user_model import Follow
from werkzeug.security import generate_password_hash, check_password_hash


class StudentService:
    @staticmethod
    def enroll_student(full_name, phone_number, student_class, father_name, mother_name,  email, password, address, course_id):
        hashed_password = generate_password_hash(password)
        new_student = Student(full_name = full_name, phone_number = phone_number, student_class = student_class, father_name = father_name, mother_name =  mother_name, email =   email, password =  hashed_password, address = address, course_id = course_id)
        db.session.add(new_student)
        db.session.commit()

        return new_student

    @staticmethod
    def get_student_by_id(student_admNo):
        return Student.query.filter_by(student_admNo =student_admNo).first()

    @staticmethod
    def get_all_students():
        return Student.query.order_by(Student.created_at.desc()).all()
    
    @staticmethod
    def get_all_students_of_class(student_class):
        return Student.query.order_by(student_class = student_class).all()

    # @staticmethod
    # def update_student(student_id, new_content):
    #     student = Student.query.filter_by(student_id=student_id).first()
    #     if student:
    #         student.content = new_content
    #         db.session.commit()
    #     return student

    # @staticmethod
    # def delete_student(student_admNo):
    #     student = Student.query.filter_by(student_admNo=student_admNo).first()
    #     if student:
    #         db.session.delete(student)
    #         db.session.commit()
    #     return student
