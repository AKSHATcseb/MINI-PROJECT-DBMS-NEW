class CourseView:
    @staticmethod
    def render_user(course):
        return {
            "course_id": course.course_id,
            "course_name": course.course_name,
            "course_duration": course.course_duration,
            "created_at": course.created_at
        }


    @staticmethod
    def render_users(courses):
        return [ CourseView.render_course(course) for course in courses]

    @staticmethod
    def render_error(message):
        return {"error": message}

    @staticmethod
    def render_success(message, course_id=None):
        response = {"message": message}
        if course_id:
            response["course_id"] = course_id
        return response
