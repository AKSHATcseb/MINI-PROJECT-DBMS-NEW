from datetime import datetime
from shared.utils.db_utils import db
from sqlalchemy.orm import relationship


class Student(db.Model):
    __tablename__ = 'students'

    student_admNo = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(50), unique=True, nullable=False)
    phone_number = db.Column(db.String(15), nullable=False, unique=True)
    student_class = db.Column(db.String(50), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(255))
    father_name = db.Column(db.String(255))
    mother_name = db.Column(db.String(255)) 
    address = db.Column(db.Text)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.course_id'), nullable=False) 
    course_name = db.Column(db.String(25))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # following = db.relationship('Follow', foreign_keys=[Follow.follower_id], back_populates='follower')

class User(db.Model):
    __tablename__ = 'faculties'

    faculty_id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(255))
    email = db.Column(db.String(50), unique=True, nullable=False)
    phone_number = db.Column(db.String(15), nullable=False, unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.course_id'), nullable=False) 
    course_name = db.Column(db.String(25))
    experience = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # following = db.relationship('Follow', foreign_keys=[Follow.follower_id], back_populates='follower')
    # followers = db.relationship('Follow', foreign_keys=[Follow.followed_id], back_populates='followed')
    # posts = db.relationship('Post', back_populates='user', lazy='dynamic')

    
class User(db.Model):
    __tablename__ = 'courses'

    course_id = db.Column(db.Integer, primary_key=True)
    course_name = db.Column(db.String(25))
    course_duration = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)