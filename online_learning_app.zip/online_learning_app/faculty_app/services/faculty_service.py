from shared.models.model import Faculty
from shared.utils.db_utils import db
# Purpose: Imports the db object (likely an SQLAlchemy instance) for database operations (e.g., adding, querying, committing).
from werkzeug.security import generate_password_hash, check_password_hash
# Provides utility functions to hash passwords (generate_password_hash) and validate them (check_password_hash).

class FacultyService:
    @staticmethod
    def create_faculty(full_name, email, course_name, experience, password_hash, phone_number):
        hashed_password = generate_password_hash(password_hash)
        new_faculty = Faculty(full_name=full_name, email=email, password_hash=hashed_password, course_name=course_name, experience=experience, phone_number = phone_number)
        db.session.add(new_faculty)
        db.session.commit()

        return new_faculty
    
    @staticmethod
    def get_faculty_by_full_name(full_name):
        return Faculty.query.filter_by(full_name = full_name).first()

    @staticmethod
    def get_all_faculties():
        return Faculty.query.all()

    @staticmethod
    def verify_faculty(full_name, password):
        faculty = Faculty.query.filter_by(full_name=full_name).first()
        if faculty and check_password_hash(faculty.password_hash, password):
            return faculty
        return None
    
    