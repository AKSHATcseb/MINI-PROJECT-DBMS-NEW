class FacultyView:
    @staticmethod
    def render_faculty(faculty):
        return {
            "faculty_id": faculty.faculty_id,
            "full_name": faculty.full_name,
            "course_name" : faculty.course_name,
            "email": faculty.email,
            "experience": faculty.experience,
        }

    @staticmethod
    def render_faculties(faculties):
        return [FacultyView.render_faculty(faculty) for faculty in faculties]

    @staticmethod
    def render_error(message):
        return {"error": message}

    @staticmethod
    def render_success(message, faculty_id=None):
        response = {"message": message}
        if faculty_id:
            response["faculty_id"] = faculty_id
        return response